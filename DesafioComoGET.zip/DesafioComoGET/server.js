//Importando o app do arquivo app.js
const app = require('./app');

require('dotenv').config({ path: 'variaveis.env' });

//Configurando servidor
app.set('port', process.env.PORT || 7777);
const server = app.listen(app.get('port'), () => {
    console.log("[SERVER - OK] ... Servidor rodando em http://localhost:3000");
});