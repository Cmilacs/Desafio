//Importação express
const express = require('express');

//Tratativa das rotas
const router = express.Router();

//Tratativa do caminho
const path = require('path');

//Rotas GET 
router.get('/', function (req, res, next) {
    res.sendFile(path.join(__dirname, './', 'views', 'index.html'));
});

router.get('/contatos', function (req, res, next) {
    res.sendFile(path.join(__dirname, './', 'views', 'contato.html'));
});

router.get('/produtos', function (req, res, next) {
    res.sendFile(path.join(__dirname, './', 'views', 'produto.html'));
});

router.get('/catalogos', function (req, res, next) {
    res.sendFile(path.join(__dirname, './', 'views', 'catalogo.html'));
});

router.get('/abertura/tipoDocx', function (req, res, next) {
    res.sendFile(path.join(__dirname, './', 'recursos', 'arquivo.docx'));
});

router.get('/abertura/tipoJpeg', function (req, res, next) {
    res.sendFile(path.join(__dirname, './', 'recursos', 'arquivo.jpeg'));
});

router.get('/abertura/tipoMp3', function (req, res, next) {
    res.sendFile(path.join(__dirname, './', 'recursos', 'arquivo.mp3'));
});

router.get('/abertura/tipoMp4', function (req, res, next) {
    res.sendFile(path.join(__dirname, './', 'recursos', 'arquivo.mp4'));
});

router.get('/abertura/tipoJson', function (req, res, next) {
    res.sendFile(path.join(__dirname, './', 'recursos', 'arquivo.json'));
});

router.get('/abertura/tipoMd', function (req, res, next) {
    res.sendFile(path.join(__dirname, './', 'recursos', 'arquivo.md'));
});

router.get('/abertura/tipoPdf', function (req, res, next) {
    res.sendFile(path.join(__dirname, './', 'recursos', 'arquivo.pdf'));
});

// Error 404 caso não encontre a URL 
router.use(function (req, res, next) {
    res.status(404).sendFile(path.join(__dirname, './', 'views', '404.html'));
});

const app = express();
app.use(router);

//Exporanto o app
module.exports = app;